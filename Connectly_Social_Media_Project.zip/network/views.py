from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from .forms import PostForm, ProfileForm, CommentForm
from .models import Post, Like, Follow

def feed(request):
    posts = Post.objects.select_related("author").prefetch_related("likes", "comments__author")
    liked_ids = set()
    if request.user.is_authenticated:
        liked_ids = set(Like.objects.filter(user=request.user).values_list("post_id", flat=True))
    return render(request, "network/feed.html", {
        "posts": posts, "post_form": PostForm(), "comment_form": CommentForm(), "liked_ids": liked_ids
    })

@login_required
@require_POST
def create_post(request):
    form = PostForm(request.POST)
    if form.is_valid():
        post = form.save(commit=False)
        post.author = request.user
        post.save()
        messages.success(request, "Your post has been published.")
    else:
        messages.error(request, "Please check your post and try again.")
    return redirect("feed")

@login_required
@require_POST
def delete_post(request, post_id):
    post = get_object_or_404(Post, pk=post_id, author=request.user)
    post.delete()
    messages.success(request, "Post deleted.")
    return redirect("feed")

@login_required
@require_POST
def add_comment(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    form = CommentForm(request.POST)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.post = post
        comment.author = request.user
        comment.save()
    return redirect("feed")

@login_required
@require_POST
def toggle_like(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    like, created = Like.objects.get_or_create(post=post, user=request.user)
    if not created:
        like.delete()
    return redirect(request.POST.get("next") or "feed")

@login_required
@require_POST
def toggle_follow(request, username):
    target = get_object_or_404(User, username=username)
    if target == request.user:
        messages.error(request, "You cannot follow your own account.")
        return redirect("profile", username=username)
    relation = Follow.objects.filter(follower=request.user, following=target)
    if relation.exists():
        relation.delete()
    else:
        try:
            Follow.objects.create(follower=request.user, following=target)
        except IntegrityError:
            pass
    return redirect("profile", username=username)

def profile(request, username):
    person = get_object_or_404(User.objects.select_related("profile"), username=username)
    is_following = request.user.is_authenticated and Follow.objects.filter(
        follower=request.user, following=person
    ).exists()
    posts = Post.objects.filter(author=person).prefetch_related("likes", "comments__author")
    liked_ids = set()
    if request.user.is_authenticated:
        liked_ids = set(Like.objects.filter(user=request.user, post__author=person).values_list("post_id", flat=True))
    return render(request, "network/profile.html", {
        "person": person, "posts": posts, "is_following": is_following, "liked_ids": liked_ids,
        "followers_count": Follow.objects.filter(following=person).count(),
        "following_count": Follow.objects.filter(follower=person).count(),
        "comment_form": CommentForm(),
    })

@login_required
def edit_profile(request):
    profile_obj = request.user.profile
    if request.method == "POST":
        form = ProfileForm(request.POST, instance=profile_obj)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated.")
            return redirect("profile", username=request.user.username)
    else:
        form = ProfileForm(instance=profile_obj)
    return render(request, "network/edit_profile.html", {"form": form})

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("feed")
    else:
        form = UserCreationForm()
    return render(request, "network/register.html", {"form": form})
