from django.contrib import admin
from .models import Profile, Post, Comment, Like, Follow

admin.site.register(Profile)
@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("id", "author", "created_at")
    search_fields = ("content", "author__username")
admin.site.register(Comment)
admin.site.register(Like)
admin.site.register(Follow)
