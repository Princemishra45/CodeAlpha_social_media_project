from django import forms
from .models import Post, Profile, Comment

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ["content", "image_url"]
        widgets = {
            "content": forms.Textarea(attrs={"rows": 3, "placeholder": "What's on your mind?"}),
            "image_url": forms.URLInput(attrs={"placeholder": "Optional image URL (https://...)"}),
        }

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ["bio", "avatar_url"]
        widgets = {
            "bio": forms.Textarea(attrs={"rows": 3, "placeholder": "A little about you"}),
            "avatar_url": forms.URLInput(attrs={"placeholder": "Optional avatar image URL"}),
        }

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ["content"]
        widgets = {"content": forms.TextInput(attrs={"placeholder": "Write a comment..."})}
