document.addEventListener("DOMContentLoaded", () => {
  // Ask before deleting a post.
  document.querySelectorAll(".delete-form").forEach((form) => {
    form.addEventListener("submit", (event) => {
      if (!window.confirm("Delete this post?")) event.preventDefault();
    });
  });
});
