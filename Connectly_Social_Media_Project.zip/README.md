# Mini Social Media Platform (Django)

Features:
- User registration, login and logout
- User profiles with bio and optional avatar URL
- Create and delete your own posts
- Comment on posts
- Like and unlike posts
- Follow and unfollow users
- Profile pages with posts, follower and following counts
- SQLite database and Django admin

## Setup

Python 3.10+ recommended.

```bash
python -m venv venv
```

Activate it:

Windows:
```bash
venv\\Scripts\\activate
```

macOS/Linux:
```bash
source venv/bin/activate
```

Install and initialize:

```bash
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/

Admin: http://127.0.0.1:8000/admin/

## First use
1. Register a user account.
2. Visit Profile to add a bio and optional avatar image URL.
3. Create a post from the home page.
4. Like posts, add comments, and follow other users.
5. Open a username on a post to view that profile.

## Database
SQLite is created as `db.sqlite3` after running migrations. Django's built-in user table stores accounts; the app adds Profile, Post, Comment, Like and Follow tables.

## Production notes
This is a learning/demo project. Before deployment, set a secret key through environment variables, set DEBUG=False, configure ALLOWED_HOSTS, HTTPS, secure cookies, static/media hosting, backups and moderation/rate limiting. Image fields currently use image URLs. No private messaging or image upload storage is included.
